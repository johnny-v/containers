var dataStorageKey = "savedUsername",
    passwordStorageKey = "savedPassword";

//Der Container feuert das "deviceready"-Event, sobald die Schnittstellen erfolgreich aufgesetzt sind und die Loginseite geladen wurde.
//Aufrufe auf die vom Container bereitgestellten Schnittstellen sind erst nach diesem Event, bzw. im Eventhandler von "deviceready" zulässig.
window.document.addEventListener("deviceready", function () {
    //Lädt den bisher gespeicherten Benutzernamen aus dem LocalStorage vom Endgerät, sofern bereits einer gespeichert wurde
    var data;
    try {
        data = JSON.parse(localStorage.getItem(dataStorageKey));
    } catch (e) {
        data = null;
    }

    //Sofern ein Benutzername im LocalStorage vom Endgerät gespeichert ist, aktiviere den Button, um die gespeicherten Daten zu löschen
    toggleChangeUserContextButton(!!data);

    if (data) {
        //Fülle die Loginform mit dem gespeicherten Benutzernamen aus
        fillOutLoginForm(data);

        window.document.loginForm.saveData.checked = true;
        onSaveDataChange();

        //Prüfe ob ein Passwort im LocalStorage vom Endgerät gespeichert ist
        if (hasPasswordInLocaleStorage()) {
            //Sofern ein Passwort im LocalStorage vom Endgerät ist gespeichert, ergänze die Loginform um das gespeicherte Passwort
            fillOutUserPasswordFromLocalStorage();
        } else {
            //Sofern kein Passwort im LocalStorage vom Endgerät gespeichert ist, prüfe ob die Fingerprint Funktion zur Verfügung steht
            window.plugins.fingerprint.isAvailable(
                function () {
                    //Die Fingerprint Funktion ist verfügbar
                    window.plugins.fingerprint.has(passwordStorageKey, function () {
                        //Ein Passwort wurde zuvor mit dem Fingerprint gespeichert

                        window.document.loginForm.useFingerprint.checked = true;

                        //Überprüfe den Fingerprint, um das Passwort auszulesen
                        window.plugins.fingerprint.verify(passwordStorageKey, "Legen Sie ihren Finger auf, um sich einzuloggen.", function (data) {
                            //Die Authentifizierung mit dem Fingerprint war erfolgreich, "data" enthält die zuvor gespeicherten Daten.
                            try {
                                data = JSON.parse(data);
                            } catch (e) {
                                data = null;
                            }

                            if (data) {
                                //Fülle die Loginform mit dem gespeicherten Passwort aus
                                fillOutLoginForm(data);
                                //Schickt die Loginform ab, um den Loginprozess in Ihrem Backend zu starten
                                window.document.loginForm.submit();
                            }
                        }, function (errorCode) {
                        });
                    }, function () {
                        //Es wurde kein gespeichertes Passwort gefunden

                    });
                },
                function (errorCode) {
                    //Die Fingerprint Funktion steht nicht zur Verfügung

                }
            );
        }
    }
}, false);

//Diese Methode prüft, ob ein Passwort im LocalStorage vom Endgerät gespeichert wurde.
function hasPasswordInLocaleStorage() {

    var data;
    try {
        data = localStorage.getItem(passwordStorageKey);
    } catch (e) {
        data = null;
    }

    return !!data;
}

//Diese Methode füllt die Loginform mit dem im LocalStorage vom Endgerät gespeicherten Passwort aus.
function fillOutUserPasswordFromLocalStorage() {

    var data;
    try {
        data = JSON.parse(localStorage.getItem(passwordStorageKey));
    } catch (e) {
        data = null;
    }

    fillOutLoginForm(data);
}

function toggleChangeUserContextButton(visible) {
    //Zeige oder verstecke den Button, der vorher gespeicherte Benutzername und Passwort löscht.
    window.document.getElementById("changeUserContextButton").style.display = visible ? "" : "none";
}

//Diese Methode löscht den gespeicherten Benutzernamen aus dem LocalStorage.
//Zusätzlich wird das gespeicherte Passwort sowohl aus der Fingerprint Funktion,
//als auch aus dem LocalStorage vom Endgerät (sofern hier ein Passwort gespeichert wurde) gelöscht.
function deleteCurrentSavedUserContext() {
    //Löscht den gespeicherten Benutzernamen aus dem LocalStorage
    try {
        localStorage.removeItem(dataStorageKey);
    } catch (e) {
    }

    //Löscht das gespeicherte Passwort aus dem LocalStorage
    try {
        localStorage.removeItem(passwordStorageKey);
    } catch (e) {
    }

    //Prüfe ob die Fingerprint Funktion zur Verfügung steht
    window.plugins.fingerprint.isAvailable(function () {
        //Die Fingerprint Funktion ist verfügbar

        //Löscht das gespeicherte Passwort aus der Fingerprint Funktion
        window.plugins.fingerprint.delete(passwordStorageKey, function () {
            //Löschen war erfolgreich
        }, function () {
            //Löschen nicht erfolgreich
        });
    }, function () {
        //Die Fingerprint Funktion nicht ist verfügbar
    });

    //Versteckt den Button, der gespeicherte Daten löscht
    toggleChangeUserContextButton(false);

    //Entferne alle Daten aus der Loginform
    fillOutLoginForm({
        userName: null,
        userPassword: null
    });
}

//Diese Methode füllt die Loginform aus
function fillOutLoginForm(data) {

    if (data) {
        if (data.hasOwnProperty("userName")) {
            window.document.loginForm.userName.value = data.userName;
        }
        if (data.hasOwnProperty("userPassword")) {
            window.document.loginForm.userPassword.value = data.userPassword;
        }

        //Überprüft die LoginForm und aktiviert bei Erfolg den Login Button
        validateLoginForm();
    }
}

//Diese Methode startet den Loginprozess im Frontend
function startLogin() {
    //Startet den Loginprozess im Frontend
    if (window.document.loginForm.saveData.checked) {
        //Die Nutzerdaten sollen gespeichert werden

        var stringData = JSON.stringify({
                "userName": window.document.loginForm.userName.value
            }),
            stringPassword = JSON.stringify({
                "userPassword": window.document.loginForm.userPassword.value
            });


        //Lade den momentan gespeicherten Benutzernamen aus dem LocalStorage vom Endgerät
        var currentSavedData;
        try {
            currentSavedData = localStorage.getItem(dataStorageKey);
        } catch (e) {
            currentSavedData = null;
        }

        //Prüfe ob bisher ein Benutzername gespeichert war, und ob dieser dem jetzigen entspricht. Sofern diese unterschiedlich sind, zeige eine Rückfrage an.
        if (currentSavedData && currentSavedData !== stringData && !window.confirm("Wollen Sie die gespeicherten Benutzerdaten überschreiben?")) {
            //Schickt die Loginform ab, um den Loginprozess in Ihrem Backend zu starten
            window.document.loginForm.submit();
        } else {

            //Speichert den Benutzernamen im LocalStorage vom Endgerät
            try {
                localStorage.setItem(dataStorageKey, stringData);
            } catch (e) {
            }

            //Prüfe ob die Fingerprint Funktion nicht genutzt werden soll
            if (!window.document.loginForm.useFingerprint.checked) {
                window.plugins.fingerprint.delete(passwordStorageKey);
                try {
                    //Speichert das Passwort im LocalStorage vom Endgerät
                    localStorage.setItem(passwordStorageKey, stringPassword);
                } catch (e) {
                } finally {
                    //Schickt die Loginform ab, um den Loginprozess in Ihrem Backend zu starten
                    window.document.loginForm.submit();
                }
            } else {
                //Prüfe ob die Fingerprint Funktion verfügbar ist
                window.plugins.fingerprint.isAvailable(function () {
                    //Die Fingerprint Funktion ist verfügbar

                    //Speichert das Passwort mit Hilfe der Fingerprint Funktion
                    window.plugins.fingerprint.save(passwordStorageKey, stringPassword,
                        function () {
                            //Das Speichern vom Passwort war erfolgreich

                            try {
                                //Löscht ein etwaig gespeichertes Passwort aus dem LocalStorage vom Endgerät
                                localStorage.removeItem(passwordStorageKey);
                            } catch (e) {
                            } finally {
                            }
                            //Schickt die Loginform ab, um den Loginprozess in Ihrem Backend zu starten
                            window.document.loginForm.submit();

                        }, function () {
                        });
                }, function (errorCode) {
                    //Die Fingerprint Funktion ist nicht verfügbar

                    try {
                        //Speichert das Passwort im LocalStorage vom Endgerät
                        localStorage.setItem(passwordStorageKey, stringPassword);
                    } catch (e) {
                    } finally {
                        //Schickt die Loginform ab, um den Loginprozess in Ihrem Backend zu starten
                        window.document.loginForm.submit();
                    }
                });
            }
        }
    } else {
        //Die Nutzerdaten sollen nicht gespeichert werden

        //Schickt die Loginform ab, um den Loginprozess in Ihrem Backend zu starten
        window.document.loginForm.submit();
    }
}

function validateLoginForm() {
    window.document.getElementById("loginButton").disabled = !window.document.loginForm.userName.value || !window.document.loginForm.userPassword.value;
}

function onSaveDataChange() {
    if (window.document.loginForm.saveData.checked) {
        window.plugins.fingerprint.isAvailable(function () {
            window.document.getElementById("useFingerprintTableRow").style.display = "";
        }, function () {
            window.document.getElementById("useFingerprintTableRow").style.display = "none";
        });
    } else {
        window.document.getElementById("useFingerprintTableRow").style.display = "none";
    }
}
