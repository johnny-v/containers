cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
  {
    "id": "brunkenconsult-cordova-plugin-fortunefingerprint.TouchID",
    "file": "plugins/brunkenconsult-cordova-plugin-fortunefingerprint/www/touchid.js",
    "pluginId": "brunkenconsult-cordova-plugin-fortunefingerprint",
    "clobbers": [
      "window.plugins.fingerprint"
    ]
  },
  {
    "id": "cordova-plugin-network-information.network",
    "file": "plugins/cordova-plugin-network-information/www/network.js",
    "pluginId": "cordova-plugin-network-information",
    "clobbers": [
      "navigator.connection",
      "navigator.network.connection"
    ]
  },
  {
    "id": "cordova-plugin-network-information.Connection",
    "file": "plugins/cordova-plugin-network-information/www/Connection.js",
    "pluginId": "cordova-plugin-network-information",
    "clobbers": [
      "Connection"
    ]
  },
  {
    "id": "cordova-plugin-inappbrowser.inappbrowser",
    "file": "plugins/cordova-plugin-inappbrowser/www/inappbrowser.js",
    "pluginId": "cordova-plugin-inappbrowser",
    "clobbers": [
      "cordova.InAppBrowser.open",
      "window.open"
    ]
  },
  {
    "id": "cordova-plugin-splashscreen.SplashScreen",
    "file": "plugins/cordova-plugin-splashscreen/www/splashscreen.js",
    "pluginId": "cordova-plugin-splashscreen",
    "clobbers": [
      "navigator.splashscreen"
    ]
  },
  {
    "id": "cordova-plugin-wkwebview-engine.ios-wkwebview-exec",
    "file": "plugins/cordova-plugin-wkwebview-engine/src/www/ios/ios-wkwebview-exec.js",
    "pluginId": "cordova-plugin-wkwebview-engine",
    "clobbers": [
      "cordova.exec"
    ]
  },
  {
    "id": "cordova-plugin-wkwebview-engine.ios-wkwebview",
    "file": "plugins/cordova-plugin-wkwebview-engine/src/www/ios/ios-wkwebview.js",
    "pluginId": "cordova-plugin-wkwebview-engine",
    "clobbers": [
      "window.WkWebView"
    ]
  }
];
module.exports.metadata = 
// TOP OF METADATA
{
  "brunkenconsult-cordova-plugin-fortunefingerprint": "1.0.0",
  "cordova-plugin-network-information": "2.0.1",
  "brunkenconsult-cordova-plugin-fortunenetworksupport": "1.0.0",
  "cordova-custom-config": "2.0.3",
  "cordova-plugin-inappbrowser": "2.0.1",
  "cordova-plugin-remote-injection": "0.4.0",
  "cordova-plugin-splashscreen": "4.1.0",
  "cordova-plugin-whitelist": "1.3.3",
  "cordova-plugin-wkwebview-engine": "1.1.4"
};
// BOTTOM OF METADATA
});